import React, { useState } from 'react';
import './style.css';
import Message from './components/Message';
import Input from './components/Input';

export default function App() {
  const [myVariable, setMyVariable] = useState('');
  const myFunc = (event) => {
    setMyVariable(event.target.value);
  };
  return (
    <div>
      <Input onChange={myFunc} />
      <Message myVariable={myVariable} />
    </div>
  );
}
